@echo off

plink -ssh dcloud@198.18.133.15 -pw C1sco12345 bash /splunk
SwithMail.exe /s /x "11ngsma-bulk.xml"
SwithMail.exe /s /x "11ngsma-bulk2.xml"
SwithMail.exe /s /x "11ngsma-vof.xml"
SwithMail.exe /s /x "11ngsma-vof2.xml"
SwithMail.exe /s /x "11ngsma-vof3.xml"
SwithMail.exe /s /x "11ngsma-spam.xml"
SwithMail.exe /s /x "11ngsma-spam2.xml"
SwithMail.exe /s /x "11ngsma-spam3.xml"
SwithMail.exe /s /x "11ngsma-virus.xml"
SwithMail.exe /s /x "11ngsma-url.xml"
SwithMail.exe /s /x "11ngsma-url2.xml"