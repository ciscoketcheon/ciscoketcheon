@echo off

SwithMail.exe /s /x "1ngsma-bulk.xml"
SwithMail.exe /s /x "1ngsma-bulk2.xml"
SwithMail.exe /s /x "1ngsma-vof.xml"
SwithMail.exe /s /x "1ngsma-vof2.xml"
SwithMail.exe /s /x "1ngsma-vof3.xml"
SwithMail.exe /s /x "1ngsma-spam.xml"
SwithMail.exe /s /x "1ngsma-spam2.xml"
SwithMail.exe /s /x "1ngsma-spam3.xml"
SwithMail.exe /s /x "1ngsma-virus.xml"
SwithMail.exe /s /x "1ngsma-url.xml"
SwithMail.exe /s /x "1ngsma-url2.xml"