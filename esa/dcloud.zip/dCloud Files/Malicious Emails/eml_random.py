#!/usr/bin/python
#coding: utf-8-unix 
#Format of the command 
#python eml_random.py mailfrom@example.com rcptto@example.com file.eml mx1.test.com'

import sys
import shutil
import os.path
import smtplib, ssl
import uuid
import datetime

from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.base import MIMEBase
from email import encoders

if len(sys.argv) <= 4:
    print('Command:')
    print('  $ python ' + sys.argv[0] + ' mailfrom rcptto <emlfile> server' )
    print('Example:')
    print('  $ python ' + sys.argv[0] + ' mailfrom@example.com rcptto@example.com mail.eml mx1.test.com')
    sys.exit(0)


# Create temporary file
now = str(datetime.datetime.now())[:19]
now = now.replace(":","_")
now = now.replace(" ","_")

src_file = sys.argv[3]
dst_file = 'tmp_' + str(now) + sys.argv[3] 
shutil.copyfile (src_file, dst_file, follow_symlinks=True)


# SMTP data

server = sys.argv[4]
port = 25
mailfrom = sys.argv[1]
rcptto = sys.argv[2].split(',')
MID = uuid.uuid4()
MIDstr = str(MID)

# headers to be added or you can manually manipulate

headers = []
headers.append ('From: ' + sys.argv[1])
headers.append ('To: ' + sys.argv[2])
headers.append ('Reply-To: ' + sys.argv[2])
headers.append ('Message-ID: <' + MIDstr + '@test.system>')

print ('ARRAY :', headers)


# File manipulation

message = ''
if len(sys.argv) >= 5:
    filename = dst_file
    if not os.path.isfile(filename):
        print('File "' + filename + '" not found.')
        sys.exit(0)
    with open(filename, 'r+') as FileEmail:
        lines = FileEmail.readlines()
        lines.insert(0, headers[0] + '\n')
        lines.insert(0, headers[1] + '\n')
        lines.insert(0, headers[2] + '\n')
        lines.insert(0, headers[3] + '\n')
        FileEmail.seek(0, os.SEEK_SET)
        FileEmail.writelines(lines)
        FileEmail.close()
        
    with open(filename) as f:    
        message = f.read()
        

smtp = None
try:
    smtp = smtplib.SMTP(server, port)
    smtp.sendmail(mailfrom, rcptto, message)
except Exception as e:
    print('Failed to send mail.')
    print(str(e))
else:
    print('Succeeded to send mail.')
finally:
    if smtp != None:
        smtp.close()