@echo off

SwithMail.exe /s /x "ngsma-bulk.xml"
SwithMail.exe /s /x "ngsma-bulk2.xml"
SwithMail.exe /s /x "ngsma-macro.xml"
SwithMail.exe /s /x "ngsma-spam.xml"
SwithMail.exe /s /x "ngsma-spam2.xml"
SwithMail.exe /s /x "ngsma-spam3.xml"
SwithMail.exe /s /x "ngsma-virus.xml"
SwithMail.exe /s /x "ngsma-vof.xml"
SwithMail.exe /s /x "ngsma-vof2.xml"
SwithMail.exe /s /x "ngsma-url.xml"
SwithMail.exe /s /x "ngsma-url2.xml"